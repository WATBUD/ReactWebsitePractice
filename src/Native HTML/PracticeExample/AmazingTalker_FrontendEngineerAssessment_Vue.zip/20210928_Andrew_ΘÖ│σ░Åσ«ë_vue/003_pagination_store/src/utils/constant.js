export const anchorTeacherPrefix = "teacher_";
