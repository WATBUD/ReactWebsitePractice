import React, { useState } from "react";
import style from "./App.module.css";

const LANGUAGE_STEP = 1;
const AGE_STEP = 2;
const FINAL_STEP = 3;

function App() {
  const [step, setStep] = useState(1);
  const [learningLanguage, setLearningLanguage] = useState({
    chinese: false,
    english: false,
    korean: false,
    spanish: false,
    japanese: false,
  });
  const [learningAge, setLearningAge] = useState({
    young: false,
    middle: false,
    old: false,
  });

  const handlePrev = () => setStep(step - 1);
  const handleNext = () => setStep(step + 1);
  const handleLanguageChange = (e) => {
    const target = e.target;
    const checked = target.checked;
    const name = target.name;
    setLearningLanguage({
      ...learningLanguage,
      [name]: checked,
    });
  };
  const handleAgeChange = (e) => {
    const target = e.target;
    const checked = target.checked;
    const name = target.name;
    setLearningAge({
      ...learningAge,
      [name]: checked,
    });
  };

  return (
    <div className={style.container}>
      {step === LANGUAGE_STEP && (
        <div className={style.card}>
          <h3>What language do you want to learn ?</h3>
          <div>
            <label htmlFor="english" className={style.label}>
              <input
                type="checkbox"
                id="english"
                name="english"
                onChange={handleLanguageChange}
                checked={learningLanguage.english}
              />
              English
            </label>
            <label htmlFor="chinese" className={style.label}>
              <input
                type="checkbox"
                id="chinese"
                name="chinese"
                onChange={handleLanguageChange}
                checked={learningLanguage.chinese}
              />
              Chinese
            </label>
            <label htmlFor="korean" className={style.label}>
              <input
                type="checkbox"
                id="korean"
                name="korean"
                onChange={handleLanguageChange}
                checked={learningLanguage.korean}
              />
              Korean
            </label>
            <label htmlFor="spanish" className={style.label}>
              <input
                type="checkbox"
                id="spanish"
                name="spanish"
                onChange={handleLanguageChange}
                checked={learningLanguage.spanish}
              />
              Spanish
            </label>
            <label htmlFor="japanese" className={style.label}>
              <input
                type="checkbox"
                id="japanese"
                name="japanese"
                onChange={handleLanguageChange}
                checked={learningLanguage.japanese}
              />
              Japanese
            </label>
          </div>
          <div className={style.btnWrapper}>
            <button onClick={handlePrev}>Prev</button>
            <button onClick={handleNext}>Next</button>
          </div>
        </div>
      )}

      {step === AGE_STEP && (
        <div className={style.card}>
          <h3>How old are you ?</h3>
          <div>
            <label htmlFor="young" className={style.label}>
              <input
                type="checkbox"
                id="young"
                name="young"
                onChange={handleAgeChange}
                checked={learningAge.young}
              />
              Below 10
            </label>
            <label htmlFor="middle" className={style.label}>
              <input
                type="checkbox"
                id="middle"
                name="middle"
                onChange={handleAgeChange}
                checked={learningAge.middle}
              />
              11 - 30
            </label>
            <label htmlFor="old" className={style.label}>
              <input
                type="checkbox"
                id="old"
                name="old"
                onChange={handleAgeChange}
                checked={learningAge.old}
              />
              Above 31
            </label>
          </div>
          <div className={style.btnWrapper}>
            <button onClick={handlePrev}>Prev</button>
            <button onClick={handleNext}>Next</button>
          </div>
        </div>
      )}

      {step === FINAL_STEP && (
        <div className={style.card}>
          <h4>Ages</h4>
          <div>
            {Object.keys(learningAge)
              .filter((key) => learningAge[key])
              .join(", ")}
          </div>
          <hr />
          <h4>Languages</h4>
          <div>
            {Object.keys(learningLanguage)
              .filter((key) => learningLanguage[key])
              .join(", ")}
          </div>
          <div className={style.btnWrapper}>
            <button onClick={handlePrev}>Prev</button>
            <button onClick={handleNext}>Next</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
