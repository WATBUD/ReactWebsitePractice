import React, { useState, useEffect } from "react";
import * as apiClient from "./utils/api";
import * as helper from "./utils/helper";
import { anchorTeacherPrefix } from "./utils/constant";

function App() {
  const [selectedTeacherId, setSelectedTeacherId] = useState(
    helper.getTeacherIdAnchor()
  );
  // TODO: focus to design teacher pagination state
  const [teachers, setTeachers] = useState([]);

  useEffect(() => {
    // TODO: fetch teacher pagination data
    apiClient.fetchTeachers().then((teachers) => setTeachers(teachers));
  }, []);

  const handleClick = (e) => {
    const teacherId = e.target.id;
    setSelectedTeacherId(Number(teacherId));
  };

  const handlePrev = () => {
    // TODO: go prev page
  };

  const handleNext = () => {
    // TODO: go next page
  };

  const handleClose = () => {
    setSelectedTeacherId(0);
  };

  const seeMoreAboutThisTeacher = teachers.find(
    (teacher) => teacher.id === selectedTeacherId
  );

  return (
    <div className="container">
      <h1>Teachers</h1>
      <ul>
        {teachers.map((teacher) => (
          <li key={teacher.id}>
            {teacher.id} | {teacher.name}
            <a
              href={`#${anchorTeacherPrefix}${teacher.id}`}
              onClick={handleClick}
              className="link"
              id={teacher.id}
            >
              see more
            </a>
          </li>
        ))}
      </ul>
      <br />
      <button onClick={handlePrev}>Previous Page</button>
      <button onClick={handleNext}>Next Page</button>

      {seeMoreAboutThisTeacher && (
        <div id="rightWindow">
          <h3>Teacher's information</h3>
          <hr />
          <div>ID: {seeMoreAboutThisTeacher.id}</div>
          <div>Name: {seeMoreAboutThisTeacher.name}</div>
          <br />
          <br />
          <h3>Speaking Language</h3>
          <hr />
          <div className="tagWrapper">
            {seeMoreAboutThisTeacher.speakLanguages.map((language) => (
              <span key={language}>{language}</span>
            ))}
          </div>
          <br />
          <br />
          <a href="#" onClick={handleClose}>
            (close this tab)
          </a>
        </div>
      )}
    </div>
  );
}

export default App;
