# 001_component_refactoring

# Questions

重構這個 Component 的架構

1. 專注於改善 Component 的拆分，css 的樣式、畫面得的美觀與否都不在審核的範圍內
1. 不需要套用其他 css,js framework

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
